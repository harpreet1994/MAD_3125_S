package com.example.macstudent.movietickets;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    ImageView logo;
    EditText edtUsername, edtPassword;
    TextView txtLogin;
    Button btnRegister;

    DBHelper dbHelper;
    SQLiteDatabase MovieDB;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtLogin = findViewById(R.id.txtLogin);
        txtLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == txtLogin.getId()) {

            if (verifyLogin()) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                Intent homeIntent = new Intent(this, HomeActivity.class);
                startActivity(homeIntent);
            } else {
                Toast.makeText(this, "Invalid username/password", Toast.LENGTH_SHORT).show();
            }
        } else if (view.getId() == btnRegister.getId()) {
            Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }


    private boolean verifyLogin() {
        try {
            MovieDB = dbHelper.getReadableDatabase();
            String columns[] = {"Username", "Password"};
            String userData[] = {edtUsername.getText().toString(), edtPassword.getText().toString()};

            Cursor cursor = MovieDB.query("UserInfo", columns,
                    "Username = ? AND Password = ?", userData, null, null, null);

            if (cursor != null) {
                if (cursor.getCount() > 0) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            Log.e("LoginActivity", e.getMessage());
            return false;
        } finally {
            MovieDB.close();
        }
    }

}
